import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/report.dart';

class DBService {
  static Database? _db;

  static Future init() async {
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'inventaris.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''CREATE TABLE reports (
        id TEXT PRIMARY KEY,
        room TEXT,
        item TEXT,
        qty INTEGER,
        condition TEXT,
        note TEXT,
        photoPath TEXT,
        synced TEXT,
        createdAt TEXT
      )''');
    });
  }

  static Future<int> insertReport(Report r) async {
    return await _db!.insert('reports', r.toMap());
  }

  static Future<List<Report>> getPendingReports() async {
    final rows = await _db!.query('reports', where: 'synced = ?', whereArgs: ['false']);
    return rows.map((r) => Report.fromMap(r)).toList();
  }

  static Future markSynced(String id) async {
    return await _db!.update('reports', {'synced': 'true'}, where: 'id = ?', whereArgs: [id]);
  }
}
