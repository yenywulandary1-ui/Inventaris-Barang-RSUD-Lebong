import 'package:cloud_firestore/cloud_firestore.dart';
import 'db_service.dart';
import '../models/report.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

class SyncService {
  static final _fire = FirebaseFirestore.instance;
  static final _storage = FirebaseStorage.instance;

  static Future syncPending() async {
    final pending = await DBService.getPendingReports();
    for(final r in pending){
      try{
        // upload photo first
        final file = File(r.photoPath);
        final ref = _storage.ref().child('reports/${r.id}.jpg');
        await ref.putFile(file);
        final url = await ref.getDownloadURL();

        final data = r.toMap();
        data['photoUrl'] = url;

        await _fire.collection('inventaris_reports').doc(r.id).set(data);
        await DBService.markSynced(r.id);
      } catch(e){
        print('sync failed: $e');
      }
    }
  }
}
