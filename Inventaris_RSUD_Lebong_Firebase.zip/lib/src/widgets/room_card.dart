// room card widget placeholder
