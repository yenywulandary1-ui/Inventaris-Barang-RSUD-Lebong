import 'package:flutter/material.dart';
import 'dashboard_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LoginScreen extends StatefulWidget { @override _LoginScreenState createState() => _LoginScreenState(); }

class _LoginScreenState extends State<LoginScreen> {
  final _emailCtl = TextEditingController();
  final _passCtl = TextEditingController();
  bool _loading = false;

  void _login() async {
    setState(()=>_loading=true);
    try{
      final cred = await FirebaseAuth.instance.signInWithEmailAndPassword(email: _emailCtl.text.trim(), password: _passCtl.text.trim());
      final user = cred.user;
      if(user!=null){
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DashboardScreen(userEmail: user.email ?? '')));
      }
    } catch(e){
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Login gagal: ' + e.toString())));
    } finally { setState(()=>_loading=false); }
  }

  @override
  Widget build(BuildContext c){
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Image.asset('assets/logo.png', height: 140),
            SizedBox(height: 12),
            Text('Inventaris RSUD Lebong', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text('Setulus Hati Kami Melayani'),
            SizedBox(height: 24),
            TextField(controller: _emailCtl, decoration: InputDecoration(labelText: 'Email')),
            TextField(controller: _passCtl, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
            SizedBox(height: 12),
            ElevatedButton(onPressed: _loading?null:_login, child: _loading?CircularProgressIndicator(color: Colors.white):Text('Masuk'))
          ]),
        ),
      ),
    );
  }
}
