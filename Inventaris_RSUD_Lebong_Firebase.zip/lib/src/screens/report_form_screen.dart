import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import '../models/report.dart';
import '../services/db_service.dart';

class ReportFormScreen extends StatefulWidget {
  final String defaultRoom;
  ReportFormScreen({required this.defaultRoom});

  @override _ReportFormScreenState createState() => _ReportFormScreenState();
}

class _ReportFormScreenState extends State<ReportFormScreen>{
  final _itemCtl = TextEditingController();
  final _qtyCtl = TextEditingController(text: '1');
  String _condition = 'Baik';
  final _noteCtl = TextEditingController();
  XFile? _photo;

  final picker = ImagePicker();

  Future pickPhoto() async {
    final p = await picker.pickImage(source: ImageSource.camera, maxWidth: 1200);
    setState((){ _photo = p; });
  }

  void submit() async {
    if(_itemCtl.text.trim().isEmpty) return ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Isi nama barang')));
    if(_photo==null) return ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Foto barang wajib')));

    final id = Uuid().v4();
    final r = Report(id: id, room: widget.defaultRoom, item: _itemCtl.text.trim(), qty: int.tryParse(_qtyCtl.text.trim()) ?? 1, condition: _condition, note: _noteCtl.text.trim(), photoPath: _photo!.path, synced: 'false', createdAt: DateTime.now().toIso8601String());

    await DBService.insertReport(r);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Laporan tersimpan (offline)')));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext c){
    return Scaffold(
      appBar: AppBar(title: Text('Form Laporan - ${widget.defaultRoom}'), leading: Padding(padding: EdgeInsets.all(6), child: Image.asset('assets/logo.png'))),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: ListView(children: [
          TextField(controller: _itemCtl, decoration: InputDecoration(labelText: 'Nama Barang')),
          TextField(controller: _qtyCtl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Jumlah Barang')),
          SizedBox(height:8),
          Text('Kondisi'),
          RadioListTile(title: Text('Baik'), value: 'Baik', groupValue: _condition, onChanged: (v){ setState(()=>_condition = v as String); }),
          RadioListTile(title: Text('Rusak Ringan'), value: 'Rusak Ringan', groupValue: _condition, onChanged: (v){ setState(()=>_condition = v as String); }),
          RadioListTile(title: Text('Rusak Berat'), value: 'Rusak Berat', groupValue: _condition, onChanged: (v){ setState(()=>_condition = v as String); }),
          TextField(controller: _noteCtl, decoration: InputDecoration(labelText: 'Catatan (opsional)')),
          SizedBox(height:12),
          ElevatedButton.icon(onPressed: pickPhoto, icon: Icon(Icons.camera_alt), label: Text(_photo==null? 'Ambil Foto (WAJIB)': 'Ganti Foto')),
          if(_photo!=null) Padding(padding: EdgeInsets.only(top:8), child: Image.file(File(_photo!.path), height:150)),
          SizedBox(height:12),
          ElevatedButton.icon(onPressed: submit, icon: Icon(Icons.send), label: Text('Kirim (Simpan Offline)'))
        ]),
      ),
    );
  }
}
