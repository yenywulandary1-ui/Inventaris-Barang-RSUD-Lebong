import 'package:flutter/material.dart';
import 'rooms_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DashboardScreen extends StatelessWidget {
  final String userEmail;
  DashboardScreen({required this.userEmail});

  @override
  Widget build(BuildContext context) {
    final isAdmin = userEmail == 'komitemutursudlebong@gmail.com' || userEmail=='admin';
    return Scaffold(
      appBar: AppBar(title: Text('Inventaris - ' + (isAdmin ? 'Admin' : 'Petugas')), leading: Padding(padding: EdgeInsets.all(6), child: Image.asset('assets/logo.png'))),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          Card(child: ListTile(title: Text('Total Barang'), subtitle: Text('...'))),
          SizedBox(height:12),
          ElevatedButton.icon(onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (_) => RoomsScreen())); }, icon: Icon(Icons.add), label: Text('Tambah Laporan')),
          SizedBox(height:8),
          ElevatedButton.icon(onPressed: (){ /* TODO: show reports */ }, icon: Icon(Icons.list), label: Text('Lihat Laporan')),
          SizedBox(height:8),
          ElevatedButton.icon(onPressed: (){ /* sync */ }, icon: Icon(Icons.sync), label: Text('Sinkronisasi'))
        ]),
      ),
    );
  }
}
