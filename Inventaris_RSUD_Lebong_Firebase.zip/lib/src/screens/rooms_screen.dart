import 'package:flutter/material.dart';
import 'report_form_screen.dart';

class RoomsScreen extends StatelessWidget {
  final List<String> rooms = ['UGD','ICU','OK','Rawat Inap Mawar','Farmasi','Laboratorium','Radiologi','Gizi','Laundry','CSSD','IPSRS','Rekam Medik'];

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Pilih Ruangan'), leading: Padding(padding: EdgeInsets.all(6), child: Image.asset('assets/logo.png'))),
      body: GridView.count(
        crossAxisCount: 2,
        padding: EdgeInsets.all(12),
        children: rooms.map((r) => Card(
          color: Colors.blue[100+(rooms.indexOf(r)%3)*100],
          child: InkWell(onTap: (){ Navigator.push(context, MaterialPageRoute(builder: (_) => ReportFormScreen(defaultRoom: r))); }, child: Center(child: Text(r, style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),)),
        )).toList(),
      ),
    );
  }
}
