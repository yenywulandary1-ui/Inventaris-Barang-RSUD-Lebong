class Report {
  String id;
  String room;
  String item;
  int qty;
  String condition;
  String note;
  String photoPath;
  String synced;
  String createdAt;

  Report({required this.id, required this.room, required this.item, required this.qty, required this.condition, required this.note, required this.photoPath, required this.synced, required this.createdAt});

  Map<String, dynamic> toMap(){
    return {
      'id': id,
      'room': room,
      'item': item,
      'qty': qty,
      'condition': condition,
      'note': note,
      'photoPath': photoPath,
      'synced': synced,
      'createdAt': createdAt,
    };
  }

  factory Report.fromMap(Map<String, dynamic> m) => Report(
    id: m['id'], room: m['room'], item: m['item'], qty: m['qty'], condition: m['condition'], note: m['note'], photoPath: m['photoPath'], synced: m['synced'], createdAt: m['createdAt']
  );
}
