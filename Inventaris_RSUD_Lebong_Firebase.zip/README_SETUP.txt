Inventaris RSUD Lebong - Starter Project (Firebase + SQLite)

Files included:
- pubspec.yaml
- lib/ (Dart source files)
- assets/logo.png (placeholder or your uploaded logo)
- android/app/google-services.json (your Firebase config copied)
- firebase_options.dart (template, replace API keys if necessary)

Quick start:
1. Install Flutter SDK (https://flutter.dev/docs/get-started/install)
2. Open terminal in project folder: /mnt/data/inventaris_rsud_lebong_project
3. Run: flutter pub get
4. Ensure android/app/google-services.json exists (it is included)
5. Run in device/emulator: flutter run
6. Build release APK: flutter build apk --release
   Output APK: build/app/outputs/flutter-apk/app-release.apk

Firebase notes:
- Project ID: inventaris-rsud-lebong
- You should verify Firebase Console settings for Authentication (enable Email/Password)
- Firebase Storage rules should be set appropriately for development/testing
- For production, secure Firestore rules and Auth.

Admin account suggestion:
- Email: komitemutursudlebong@gmail.com (create in Firebase Auth) 
- Password: set via Firebase Console or via admin registration flow (not included)

If you want, I can now compress the project into a ZIP and provide a download link.
